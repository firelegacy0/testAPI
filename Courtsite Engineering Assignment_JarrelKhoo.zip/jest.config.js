module.exports = {
  testEnvironment: 'node',
  // setupFilesAfterEnv: ['./jest.setup.js'],
  transform: {},
  transformIgnorePatterns: [],
  cache: false
};
