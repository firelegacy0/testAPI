// jest.setup.js
process.env.NODE_OPTIONS = '--experimental-vm-modules'